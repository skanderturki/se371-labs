const mongoose = require('mongoose');

const bookSchema = new mongoose.Schema({

});

module.exports = mongoose.model('Book', bookSchema);